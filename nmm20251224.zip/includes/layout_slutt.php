    </div> <!-- /.container -->
</main>

<footer class="site-footer">
    <div class="container">
        <div class="site-footer-inner">
            &copy; <?= date('Y') ?> SkipsWeb - Feilmeldinger, kommentarer, spørsmål og ønsker kan du sende til
            <a class="footer-link" href="mailto:webman@skipsweb.no">webman@skipsweb.no</a>
            &nbsp;|&nbsp;
            <a class="footer-link" href="<?= h(BASE_URL); ?>/doc/UM_NMMPrimus.pdf" target="_blank">
                Brukerhåndbok
            </a>
        </div>
    </div>
</footer>

</body>
</html>
