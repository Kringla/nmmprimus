<?php
declare(strict_types=1);

define('DB_HOST', 'hostmaster.onnet.no');
define('DB_NAME', 'skipsweb_nmmprimus'); // navnet du valgte i phpMyAdmin
define('DB_USER', 'skipsweb_primus');  
define('DB_PASS', 'Use!Web?');     
