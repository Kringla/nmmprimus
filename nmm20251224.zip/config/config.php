<?php
declare(strict_types=1);

// config/config.php
// Kun konfigurasjon – ingen DB-tilkobling her

define('DB_HOST', 'localhost');
define('DB_NAME', 'nmmprimus');
define('DB_USER', 'root');
define('DB_PASS', '');
