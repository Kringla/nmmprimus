<?php
// PRODUKSJON/LOKAL under undermappe:
define('BASE_URL', '/nmmprimus');

// Hvis nettstedet ligger i domenets rot, bruk:
// define('BASE_URL', '');
