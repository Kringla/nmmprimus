<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/layout_start.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../primus/primus_modell.php';

require_login();

$fotoId = filter_input(INPUT_GET, 'Foto_ID', FILTER_VALIDATE_INT);
$ret    = (string)($_GET['ret'] ?? '');
$mode   = (string)($_GET['mode'] ?? '');

// Debug: log what we received
error_log("fartoy_velg.php - Foto_ID: " . var_export($fotoId, true) . ", ret: " . var_export($ret, true) . ", mode: " . var_export($mode, true));

if (!$fotoId || $ret === '') {
    error_log("fartoy_velg.php - Missing Foto_ID or ret, redirecting to main");
    redirect('/nmmprimus/modules/primus/primus_main.php');
}

$sok = trim((string)($_GET['sok'] ?? ''));
$liste = primus_hent_skip_liste($sok);

?>
<div class="container-fluid">
    <h1>Velg fartøy</h1>

    <div class="card">
        <div class="card-body">

            <form method="get" class="mb-3" style="display:flex; gap:12px; align-items:end;">
                <input type="hidden" name="Foto_ID" value="<?= h((string)$fotoId) ?>">
                <input type="hidden" name="ret" value="<?= h($ret) ?>">
                <?php if ($mode !== ''): ?>
                    <input type="hidden" name="mode" value="<?= h($mode) ?>">
                <?php endif; ?>

                <div>
                    <label for="sok">Søk fartøynavn</label><br>
                    <input type="text"
                           id="sok"
                           name="sok"
                           value="<?= h($sok) ?>"
                           style="max-width:40ch; width:100%;"
                           autofocus>
                </div>

                <div>
                    <button class="btn btn-primary" type="submit">Søk</button>
                    <a class="btn btn-secondary" href="<?= h($ret) ?>">Tilbake</a>
                </div>
            </form>

            <?php if (empty($liste)): ?>
                <p>Ingen fartøy funnet.</p>
            <?php else: ?>

                <!-- Scroll-container: maks 25 rader -->
                <div style="
                    max-height: 25em;
                    overflow-y: auto;
                    border: 1px solid #ddd;
                ">

                    <table class="table table-hover table-sm" style="margin-bottom:0;">
                        <thead style="position: sticky; top: 0; background: #fff; z-index: 1;">
                        <tr>
                            <th>Type</th>
                            <th>Navn</th>
                            <th>Bygd</th>
                            <th>Kallesignal</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($liste as $r): ?>
                            <?php
                            $id  = (string)($r['NMM_ID'] ?? '');
                            $fty = (string)($r['FTY'] ?? '');
                            $fna = (string)($r['FNA'] ?? '');
                            $byg = (string)($r['BYG'] ?? '');
                            $kal = (string)($r['KAL'] ?? '');

                            // Use appropriate parameter name based on mode
                            $param = ($mode === 'add_avbildet') ? 'add_avbildet_nmm_id' : 'add_nmm_id';

                            // Build return URL - handle both relative and absolute paths
                            $returnUrl = $ret;
                            if (!str_starts_with($ret, 'http') && !str_starts_with($ret, '/')) {
                                // Relative path - prepend ../primus/
                                $returnUrl = '../primus/' . $ret;
                            }

                            $url = $returnUrl
                                . (str_contains($returnUrl, '?') ? '&' : '?')
                                . $param . '=' . rawurlencode($id);
                            ?>
                            <tr>
                                <td><?= h($fty) ?></td>
                                <td><?= h($fna) ?></td>
                                <td><?= h($byg) ?></td>
                                <td><?= h($kal) ?></td>
                                <td>
                                    <a class="btn btn-success btn-sm" href="<?= h($url) ?>">
                                        Velg
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                </div>

                <div class="mt-2 text-muted">
                    Viser inntil 25 rader. Scroll for flere treff.
                </div>

            <?php endif; ?>

        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/layout_slutt.php'; ?>
